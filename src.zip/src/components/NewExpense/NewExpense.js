import ExpenseForm from "./ExpenseForm";
import "./NewExpense.css";
const NewExpense = () => {
	const saveExpenseFn = (data) => {
		const expenseData = { ...data, id: Math.random().toString() }
	}
	return (
		<div className="new-expense">
			NewExpense
			<ExpenseForm />
		</div>
	);
};
export default NewExpense;
